package com.company;

public class Main {

    public static void main(String[] args) {
	quadratic quad1 = new quadratic(-10.5,8,7);
	quad1.directionOfOpening();
	quad1.vertexForm();
	quad1.zeros();

	quadratic posQuad = new quadratic(10,9,4);

	}
}
